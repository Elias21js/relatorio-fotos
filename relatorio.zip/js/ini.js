import REGISTRO from "./relatorio.js";

// Inicialização ao carregar a página
{
  await REGISTRO.init();
}
